package in.learncodewithrk.parkingapp.Booking;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import in.learncodewithrk.parkingapp.R;


import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.Objects;

public class SlotBook extends AppCompatActivity {

    TextView occupied,vacant;
    Button Detail;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String userId;
    FirebaseFirestore db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slotdisplay);

        occupied = findViewById(R.id.occupied);
        vacant = findViewById(R.id.vacant);

        db = FirebaseFirestore.getInstance();
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        userId = Objects.requireNonNull(fAuth.getCurrentUser()).getUid();

        DocumentReference contactListener = db.collection("yolo1").document("slot");
        contactListener.addSnapshotListener(new EventListener<DocumentSnapshot>() {

            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                assert documentSnapshot != null;

                occupied.setText(documentSnapshot.getString("occupied"));
                vacant.setText(documentSnapshot.getString("vacant"));


            }
        });
        Detail = (Button) findViewById(R.id.Detail);
        Detail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent streamIntent = new Intent(SlotBook.this, Slot_area.class);
                startActivity(streamIntent);
            }
        });

    }
}