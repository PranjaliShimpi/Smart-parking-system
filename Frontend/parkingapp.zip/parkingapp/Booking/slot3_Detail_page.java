package in.learncodewithrk.parkingapp.Booking;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import in.learncodewithrk.parkingapp.home.QrActivity;
import in.learncodewithrk.parkingapp.R;
import in.learncodewithrk.parkingapp.home.payment_page;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.Objects;

public class slot3_Detail_page extends AppCompatActivity {

        TextView Slot_id,vehicle_id,Time,Phone_No;
        Button pay_now,qrcode;
        FirebaseAuth fAuth;
        FirebaseFirestore fStore;
        String userId;
        FirebaseFirestore db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slot3_detail_page);


        Slot_id = findViewById(R.id.Slot_id);
        vehicle_id = findViewById(R.id.vehicle_id);
        Time = findViewById(R.id.Time);
        Phone_No = findViewById(R.id.Phone_No);


        qrcode = findViewById(R.id.qrcode);
        db = FirebaseFirestore.getInstance();
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        userId = Objects.requireNonNull(fAuth.getCurrentUser()).getUid();

        DocumentReference contactListener = db.collection("slot2").document("slot3");
        contactListener.addSnapshotListener(new EventListener<DocumentSnapshot>() {





            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                assert documentSnapshot != null;

                Slot_id.setText(documentSnapshot.getString("Slot"));
                vehicle_id.setText(documentSnapshot.getString("Vehicle"));
                Time.setText(documentSnapshot.getString("Time"));
                Phone_No.setText(documentSnapshot.getString("Phone"));

            }
        });


        qrcode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent qrAct = new Intent(slot3_Detail_page.this, booking_slot3.class);
                startActivity(qrAct);
                finish();
            }
        });





    }
}