package in.learncodewithrk.parkingapp.home;


import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;


import in.learncodewithrk.parkingapp.R;


public class userdetail extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userdetail);



    }


}